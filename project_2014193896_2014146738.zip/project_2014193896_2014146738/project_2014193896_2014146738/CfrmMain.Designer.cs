﻿namespace project_2014193896_2014146738
{
    partial class CfrmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlPlayground = new System.Windows.Forms.Panel();
            this.lblBlocksLeft = new System.Windows.Forms.Label();
            this.lstbxHistory = new System.Windows.Forms.ListBox();
            this.lblChancesLeft = new System.Windows.Forms.Label();
            this.btnCollide = new System.Windows.Forms.Button();
            this.btnSetVelocity = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnPause = new System.Windows.Forms.Button();
            this.btnResume = new System.Windows.Forms.Button();
            this.txtX = new System.Windows.Forms.TextBox();
            this.txtY = new System.Windows.Forms.TextBox();
            this.btnRegister1 = new System.Windows.Forms.Button();
            this.btnUnregister1 = new System.Windows.Forms.Button();
            this.btnUndecorate1 = new System.Windows.Forms.Button();
            this.btnDecorate1 = new System.Windows.Forms.Button();
            this.btnDecorateMethod = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // pnlPlayground
            // 
            this.pnlPlayground.Location = new System.Drawing.Point(12, 12);
            this.pnlPlayground.Name = "pnlPlayground";
            this.pnlPlayground.Size = new System.Drawing.Size(581, 316);
            this.pnlPlayground.TabIndex = 0;
            // 
            // lblBlocksLeft
            // 
            this.lblBlocksLeft.AutoSize = true;
            this.lblBlocksLeft.Location = new System.Drawing.Point(634, 22);
            this.lblBlocksLeft.Name = "lblBlocksLeft";
            this.lblBlocksLeft.Size = new System.Drawing.Size(66, 13);
            this.lblBlocksLeft.TabIndex = 1;
            this.lblBlocksLeft.Text = "Blocks Left: ";
            // 
            // lstbxHistory
            // 
            this.lstbxHistory.FormattingEnabled = true;
            this.lstbxHistory.Location = new System.Drawing.Point(599, 38);
            this.lstbxHistory.Name = "lstbxHistory";
            this.lstbxHistory.Size = new System.Drawing.Size(198, 290);
            this.lstbxHistory.TabIndex = 2;
            // 
            // lblChancesLeft
            // 
            this.lblChancesLeft.AutoSize = true;
            this.lblChancesLeft.Location = new System.Drawing.Point(634, 334);
            this.lblChancesLeft.Name = "lblChancesLeft";
            this.lblChancesLeft.Size = new System.Drawing.Size(76, 13);
            this.lblChancesLeft.TabIndex = 3;
            this.lblChancesLeft.Text = "Chances Left: ";
            // 
            // btnCollide
            // 
            this.btnCollide.Location = new System.Drawing.Point(625, 350);
            this.btnCollide.Name = "btnCollide";
            this.btnCollide.Size = new System.Drawing.Size(155, 34);
            this.btnCollide.TabIndex = 4;
            this.btnCollide.Text = "Balls Collide";
            this.btnCollide.UseVisualStyleBackColor = true;
            // 
            // btnSetVelocity
            // 
            this.btnSetVelocity.Location = new System.Drawing.Point(12, 335);
            this.btnSetVelocity.Name = "btnSetVelocity";
            this.btnSetVelocity.Size = new System.Drawing.Size(113, 23);
            this.btnSetVelocity.TabIndex = 5;
            this.btnSetVelocity.Text = "Set Velocity";
            this.btnSetVelocity.UseVisualStyleBackColor = true;
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(13, 361);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 23);
            this.btnReset.TabIndex = 6;
            this.btnReset.Text = "Reset Game";
            this.btnReset.UseVisualStyleBackColor = true;
            // 
            // btnPause
            // 
            this.btnPause.Location = new System.Drawing.Point(94, 361);
            this.btnPause.Name = "btnPause";
            this.btnPause.Size = new System.Drawing.Size(75, 23);
            this.btnPause.TabIndex = 7;
            this.btnPause.Text = "Pause";
            this.btnPause.UseVisualStyleBackColor = true;
            // 
            // btnResume
            // 
            this.btnResume.Location = new System.Drawing.Point(175, 361);
            this.btnResume.Name = "btnResume";
            this.btnResume.Size = new System.Drawing.Size(75, 23);
            this.btnResume.TabIndex = 8;
            this.btnResume.Text = "Resume";
            this.btnResume.UseVisualStyleBackColor = true;
            // 
            // txtX
            // 
            this.txtX.Location = new System.Drawing.Point(131, 335);
            this.txtX.Name = "txtX";
            this.txtX.Size = new System.Drawing.Size(55, 20);
            this.txtX.TabIndex = 9;
            // 
            // txtY
            // 
            this.txtY.Location = new System.Drawing.Point(192, 334);
            this.txtY.Name = "txtY";
            this.txtY.Size = new System.Drawing.Size(58, 20);
            this.txtY.TabIndex = 10;
            // 
            // btnRegister1
            // 
            this.btnRegister1.Location = new System.Drawing.Point(271, 334);
            this.btnRegister1.Name = "btnRegister1";
            this.btnRegister1.Size = new System.Drawing.Size(89, 23);
            this.btnRegister1.TabIndex = 11;
            this.btnRegister1.Text = "Register Ball 1";
            this.btnRegister1.UseVisualStyleBackColor = true;
            // 
            // btnUnregister1
            // 
            this.btnUnregister1.Location = new System.Drawing.Point(271, 363);
            this.btnUnregister1.Name = "btnUnregister1";
            this.btnUnregister1.Size = new System.Drawing.Size(89, 23);
            this.btnUnregister1.TabIndex = 12;
            this.btnUnregister1.Text = "Unregister Ball";
            this.btnUnregister1.UseVisualStyleBackColor = true;
            // 
            // btnUndecorate1
            // 
            this.btnUndecorate1.Location = new System.Drawing.Point(366, 363);
            this.btnUndecorate1.Name = "btnUndecorate1";
            this.btnUndecorate1.Size = new System.Drawing.Size(89, 23);
            this.btnUndecorate1.TabIndex = 14;
            this.btnUndecorate1.Text = "Decorate Ball 2";
            this.btnUndecorate1.UseVisualStyleBackColor = true;
            // 
            // btnDecorate1
            // 
            this.btnDecorate1.Location = new System.Drawing.Point(366, 334);
            this.btnDecorate1.Name = "btnDecorate1";
            this.btnDecorate1.Size = new System.Drawing.Size(89, 23);
            this.btnDecorate1.TabIndex = 13;
            this.btnDecorate1.Text = "Decorate Ball 1";
            this.btnDecorate1.UseVisualStyleBackColor = true;
            // 
            // btnDecorateMethod
            // 
            this.btnDecorateMethod.Location = new System.Drawing.Point(461, 334);
            this.btnDecorateMethod.Name = "btnDecorateMethod";
            this.btnDecorateMethod.Size = new System.Drawing.Size(132, 52);
            this.btnDecorateMethod.TabIndex = 15;
            this.btnDecorateMethod.Text = "Decorate Method";
            this.btnDecorateMethod.UseVisualStyleBackColor = true;
            // 
            // CfrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(809, 398);
            this.Controls.Add(this.btnDecorateMethod);
            this.Controls.Add(this.btnUndecorate1);
            this.Controls.Add(this.btnDecorate1);
            this.Controls.Add(this.btnUnregister1);
            this.Controls.Add(this.btnRegister1);
            this.Controls.Add(this.txtY);
            this.Controls.Add(this.txtX);
            this.Controls.Add(this.btnResume);
            this.Controls.Add(this.btnPause);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnSetVelocity);
            this.Controls.Add(this.btnCollide);
            this.Controls.Add(this.lblChancesLeft);
            this.Controls.Add(this.lstbxHistory);
            this.Controls.Add(this.lblBlocksLeft);
            this.Controls.Add(this.pnlPlayground);
            this.Name = "CfrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CSIS2664(2016)";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlPlayground;
        private System.Windows.Forms.Label lblBlocksLeft;
        private System.Windows.Forms.ListBox lstbxHistory;
        private System.Windows.Forms.Label lblChancesLeft;
        private System.Windows.Forms.Button btnCollide;
        private System.Windows.Forms.Button btnSetVelocity;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnPause;
        private System.Windows.Forms.Button btnResume;
        private System.Windows.Forms.TextBox txtX;
        private System.Windows.Forms.TextBox txtY;
        private System.Windows.Forms.Button btnRegister1;
        private System.Windows.Forms.Button btnUnregister1;
        private System.Windows.Forms.Button btnUndecorate1;
        private System.Windows.Forms.Button btnDecorate1;
        private System.Windows.Forms.Button btnDecorateMethod;
    }
}

