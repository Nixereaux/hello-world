﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_2014193896_2014146738
{
    abstract class Unit
    {
        string ID;
        string Name;
        int Height, Width, PositionX, PositionY;

        #region Class Ball
        public abstract class Ball : Unit
        {

        }
        #endregion
        #region Class Block
        public abstract class Block : Unit
        {

        }
        #endregion
    }
}
