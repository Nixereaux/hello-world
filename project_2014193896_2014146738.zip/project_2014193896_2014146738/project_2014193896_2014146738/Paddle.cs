﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_2014193896_2014146738
{
    class Paddle
    {

    }
}
