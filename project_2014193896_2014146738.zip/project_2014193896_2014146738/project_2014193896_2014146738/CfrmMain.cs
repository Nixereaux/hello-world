﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_2014193896_2014146738
{
    public partial class CfrmMain : Form
    {
        public CfrmMain()
        {
            InitializeComponent();
        }
    }
}
